<?php
$num1 = $_POST["num1"];
$num2 = $_POST["num2"];



$add = $num1 + $num2;

echo "Addition Is:" . $add;



?>